
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Phiên bản</b> 0.1.0
    </div>
    <strong>Bản quyền &copy; ABC Inc. 2018-<?php echo date('Y') ?>.</strong> All rights reserved.
  </footer>

  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

</body>
</html>
